# ================= DATA VISUALIZATION =================

import matplotlib.pyplot as plt
import random


def show_mock_graph():

    # ================= MOCK DATA (LOOP + LIST) =================
    days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    temps = [random.randint(10, 30) for _ in range(7)]

    # ================= GRAPH DISPLAY =================
    plt.figure()
    plt.bar(days, temps)
    plt.title("Weekly Temperature")
    plt.xlabel("Days")
    plt.ylabel("Temperature (°C)")
    plt.show()
