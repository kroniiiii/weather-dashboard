# ================= WEATHER API CLASS =================
# Handles API requests and error handling

import requests
from config import API_KEY, BASE_URL


class WeatherAPI:

    @staticmethod
    def get_weather(city):

        # ================= API REQUEST =================
        try:
            params = {
                "q": city,
                "appid": API_KEY,
                "units": "metric"
            }

            response = requests.get(BASE_URL, params=params)
            data = response.json()

            if response.status_code != 200:
                return None

            # ================= DATA STRUCTURE =================
            return {
                "city": data["name"],
                "temperature": data["main"]["temp"],
                "condition": data["weather"][0]["description"],
                "humidity": data["main"]["humidity"],
                "wind": data["wind"]["speed"]
            }

        except Exception as e:
            print("API Error:", e)
            return None
