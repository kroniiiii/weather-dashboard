# ================= USER INTERFACE =================

import tkinter as tk
from tkinter import messagebox
from weather_api import WeatherAPI
from utils import show_mock_graph
from favorites import save_city, get_all_cities


class WeatherApp:

    def __init__(self, root):

        # ================= MAIN WINDOW SETTINGS =================
        self.root = root
        self.root.title("Weather Dashboard")
        self.root.geometry("700x600")
        self.root.configure(bg="#c7d5e0")  # #style background

        self.current_city = None
        self.create_widgets()

    def create_widgets(self):

        # ================= TITLE SECTION =================
        title = tk.Label(
            self.root,
            text="⚙ Weather Dashboard",
            font=("Arial", 22, "bold"),
            bg="#c7d5e0"
        )
        title.pack(pady=20)

        # ================= SEARCH SECTION =================
        search_frame = tk.Frame(self.root, bg="#c7d5e0")
        search_frame.pack(pady=10)

        tk.Label(search_frame, text="Enter City:",
                 font=("Arial", 14),
                 bg="#c7d5e0").pack(side="left", padx=5)

        self.city_entry = tk.Entry(search_frame, width=25, font=("Arial", 12))
        self.city_entry.pack(side="left", padx=5)

        tk.Button(search_frame,
                  text="Search 🔍",
                  command=self.search_weather).pack(side="left", padx=5)

        # ================= WEATHER CARD STYLE =================
        self.weather_frame = tk.Frame(self.root,
                                      bg="#eeeeee",
                                      bd=2,
                                      relief="groove")
        self.weather_frame.pack(pady=20, padx=50, fill="x")

        self.result_label = tk.Label(self.weather_frame,
                                     text="Current weather will appear here.",
                                     font=("Arial", 13),
                                     bg="#eeeeee",
                                     justify="center")
        self.result_label.pack(pady=20)

        # ================= GRAPH SECTION =================
        graph_title = tk.Label(self.root,
                               text="📊 Weekly Temperature Graph",
                               font=("Arial", 16, "bold"),
                               bg="#c7d5e0")
        graph_title.pack(pady=10)

        tk.Button(self.root,
                  text="Show Graph",
                  command=show_mock_graph).pack(pady=5)

        # ================= ACTION BUTTONS =================
        button_frame = tk.Frame(self.root, bg="#c7d5e0")
        button_frame.pack(pady=20)

        tk.Button(button_frame, text="💾 Save City", command=self.save_city).pack(side="left", padx=10)
        tk.Button(button_frame, text="📌 Favorites", command=self.show_favorites).pack(side="left", padx=10)
        tk.Button(button_frame, text="🚪 Logout").pack(side="left", padx=10)

    # ================= SEARCH FUNCTION =================
    def search_weather(self):

        city = self.city_entry.get()

        if not city:
            messagebox.showwarning("Input Error", "Please enter a city name.")
            return

        data = WeatherAPI.get_weather(city)

        if data:
            result = f"""☀ Current Weather in {data['city']}

Temperature: {data['temperature']}°C
Condition: {data['condition']}
Humidity: {data['humidity']}%
Wind Speed: {data['wind']} m/s
"""
            self.result_label.config(text=result)
            self.current_city = data['city']
        else:
            messagebox.showerror("Error", "City not found or API error.")

        # ================= SAVE CITY =================

    def save_city(self):

        if not self.current_city:
            messagebox.showwarning("Warning", "Search a city first.")
            return

        success = save_city(self.current_city)

        if success:
            messagebox.showinfo("Success", "City saved to favorites!")
        else:
            messagebox.showwarning("Duplicate", "City already saved.")

        # ================= SHOW FAVORITES =================

    def show_favorites(self):

        cities = get_all_cities()

        if not cities:
            messagebox.showinfo("Favorites", "No saved cities yet.")
            return

        fav_window = tk.Toplevel(self.root)
        fav_window.title("Favorite Cities")
        fav_window.geometry("300x300")

        tk.Label(fav_window,
                 text="Saved Cities",
                 font=("Arial", 14, "bold")).pack(pady=10)

        listbox = tk.Listbox(fav_window, font=("Arial", 12))
        listbox.pack(fill="both", expand=True, padx=20, pady=10)

        for city in cities:
            listbox.insert(tk.END, city)