# ================= MAIN ENTRY POINT =================

import tkinter as tk
from ui import WeatherApp

if __name__ == "__main__":  # #main execution
    root = tk.Tk()
    app = WeatherApp(root)
    root.mainloop()
