
import json
import os

FILE_NAME = "favorites.json"

def load_cities():
    if not os.path.exists(FILE_NAME):
        return []
    with open(FILE_NAME, "r") as f:
        return json.load(f)

def save_city(city):
    cities = load_cities()
    if city in cities:
        return False
    cities.append(city)
    with open(FILE_NAME, "w") as f:
        json.dump(cities, f)
    return True

def get_all_cities():
    return load_cities()
