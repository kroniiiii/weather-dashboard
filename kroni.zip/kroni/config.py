# ================= CONFIG FILE =================
# Stores API configuration settings

API_KEY = "19372371bd6259129540b05f4df556e9"
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"
